function dashState(){
  return getDashboardState();
}

function dashData(){
  return getDashboardData();
}

function escapeHtml(text){
  if(!text) return '';
  return String(text).replace(/[&<>]/g,(char)=>({ '&':'&amp;','<':'&lt;','>':'&gt;'}[char]));
}

function formatPostDate(iso){
  if(!iso) return '-';
  const d = new Date(iso);
  return d.toLocaleDateString('id-ID',{ day:'2-digit', month:'short' });
}

function computeOverviewLeaders(){
  const data = dashData();
  const accounts = (data && data.accounts) || [];
  if(!accounts.length) return null;
  const rankedFollowers = [...accounts].sort((a,b) => (b.f||0) - (a.f||0));
  const rankedER = [...accounts].sort((a,b) => (b.er||0) - (a.er||0));
  const rankedGrowth = [...accounts].sort((a,b) => (b.growthAbs||0) - (a.growthAbs||0));
  const rankedGrowthPct = [...accounts].sort((a,b) => (b.growthPct||0) - (a.growthPct||0));
  const formatTotals = { reels:0, carousel:0, image:0, video:0 };
  Object.values(data.contentBreakdown || {}).forEach(function(cb){
    ['reels','carousel','image','video'].forEach(function(t){
      formatTotals[t] += Number(cb[t] || 0);
    });
  });
  const topFormat = Object.entries(formatTotals).sort((a,b) => b[1]-a[1])[0] || ['reels',0];
  return {
    topFollowers: rankedFollowers[0],
    topER: rankedER[0],
    topGrowth: rankedGrowth[0],
    topGrowthPct: rankedGrowthPct[0],
    topFormat,
    formatTotals
  };
}

function renderExecutiveSummary(){
  const el = document.getElementById('executiveSummary');
  if(!el) return;
  const data = dashData();
  const leaders = computeOverviewLeaders();
  const brand = getBrand();
  const competitors = getCompetitors();
  if(!data || !leaders || !brand){
    el.innerHTML = '';
    return;
  }

  const rankedFollowers = [...(data.accounts || [])].sort((a,b) => (b.f||0) - (a.f||0));
  const brandRank = rankedFollowers.findIndex((account) => account.u === brand.u) + 1;
  const erPct = function(value){ return value == null ? '-' : ((value || 0) * 100).toFixed(2) + '%'; };
  const closestFollower = competitors.slice().sort((a,b) => Math.abs((a.f||0) - (brand.f||0)) - Math.abs((b.f||0) - (brand.f||0)))[0] || null;
  const strongestER = leaders.topER;
  const brandGap = closestFollower ? (brand.f || 0) - (closestFollower.f || 0) : 0;
  const brandGrowth = brand.growthAbs || 0;
  const topDailyGrowth = leaders.topGrowth;
  const erDelta = strongestER ? ((brand.er || 0) - (strongestER.er || 0)) : 0;
  const cards = [
    {
      k:'Posisi Brand',
      v: brandRank ? `#${brandRank}` : '-',
      s: closestFollower ? `Followers ${brandGap >= 0 ? 'unggul' : 'tertinggal'} ${fmtFull(Math.abs(brandGap))} vs @${closestFollower.u}` : 'Belum ada akun pembanding terdekat.',
      tone:'brand'
    },
    {
      k:'Gap Rival Terdekat',
      v: !closestFollower ? '-' : `${brandGap >= 0 ? '+' : '-'}${fmtFull(Math.abs(brandGap))}`,
      s: closestFollower ? `Dibanding @${closestFollower.u} pada total followers.` : 'Menunggu data pembanding.',
      tone: brandGap >= 0 ? 'positive' : 'warning'
    },
    {
      k:'Growth Hari Ini',
      v: `${brandGrowth >= 0 ? '+' : ''}${fmtFull(brandGrowth)}`,
      s: topDailyGrowth ? `Akun paling naik hari ini @${topDailyGrowth.u} (${topDailyGrowth.growthAbs >= 0 ? '+' : ''}${fmtFull(topDailyGrowth.growthAbs || 0)})` : 'Belum ada perubahan harian yang tercatat.',
      tone: brandGrowth >= 0 ? 'positive' : 'warning'
    },
    {
      k:'ER Brand',
      v: erPct(brand.er),
      s: !strongestER ? 'Belum ada data engagement.' : strongestER.u === brand.u ? 'Brand memimpin ER di kelompok akun ini.' : `Selisih ${erDelta >= 0 ? '+' : '-'}${erPct(Math.abs(erDelta))} vs @${strongestER.u}`,
      tone: strongestER && strongestER.u === brand.u ? 'positive' : 'brand'
    }
  ];

  el.innerHTML = cards.map(function(card){
    return `<article class="summary-card highlight" data-tone="${card.tone || 'brand'}" title="${escapeHtml(card.s)}"><div class="k">${card.k}</div><div class="v">${card.v}</div><div class="s">${card.s}</div></article>`;
  }).join('');
}

function renderTodaySummary(){
  const el = document.getElementById('todaySummary');
  if(!el) return;
  const data = dashData();
  const leaders = computeOverviewLeaders();
  const brand = getBrand();
  if(!data || !leaders || !brand){
    el.innerHTML = '';
    return;
  }
  const topGrowth = leaders.topGrowth;
  const topER = leaders.topER;
  const topFollowers = leaders.topFollowers;
  const brandGrowth = brand.growthAbs || 0;
  const tone = brandGrowth > 0 ? 'positif' : brandGrowth < 0 ? 'melemah' : 'stabil';
  const items = [
    `Hari ini performa brand @${brand.u} cenderung <strong>${tone}</strong> dengan perubahan followers <strong>${brandGrowth >= 0 ? '+' : ''}${fmtFull(brandGrowth)}</strong>.`,
    topGrowth ? `Pergerakan followers tercepat saat ini datang dari <strong>@${topGrowth.u}</strong> (${topGrowth.growthAbs >= 0 ? '+' : ''}${fmtFull(topGrowth.growthAbs)} hari ini).` : '',
    topER ? `Akun dengan engagement rate tertinggi adalah <strong>@${topER.u}</strong> di level <strong>${pct(topER.er || 0)}</strong>.` : '',
    topFollowers ? `Pemimpin total followers tetap <strong>@${topFollowers.u}</strong> dengan <strong>${fmtFull(topFollowers.f || 0)}</strong> followers.` : ''
  ].filter(Boolean);

  el.innerHTML = `
    <div class="today-summary-card neo">
      <div class="today-summary-head">
        <div>
          <div class="today-summary-k">Ringkasan Hari Ini</div>
          <div class="today-summary-v">Sorotan paling penting dari update terbaru</div>
        </div>
        <div class="today-summary-chip">${prettyLastUpdate(data.lastUpdate || '-')}</div>
      </div>
      <ol class="today-summary-list">${items.map((item)=>`<li>${item}</li>`).join('')}</ol>
    </div>
  `;
}

function renderSummaryStrip(){
  var el = document.getElementById('summaryStrip');
  if(!el || !dashData() || !dashData().accounts || !dashData().accounts.length) return;
  var leaders = computeOverviewLeaders();
  var cards = [
    { k:'Pemimpin Followers', v:'@' + leaders.topFollowers.u, s: fmtFull(leaders.topFollowers.f) + ' followers', cls:'highlight' },
    { k:'ER Tertinggi', v:'@' + leaders.topER.u, s: ((leaders.topER.er || 0) * 100).toFixed(2) + '% tingkat interaksi' },
    { k:'Pertumbuhan Tercepat', v:'@' + leaders.topGrowth.u, s: (leaders.topGrowth.growthAbs >= 0 ? '+' : '') + fmtFull(leaders.topGrowth.growthAbs || 0) + ' hari ini' },
    { k:'Format Dominan', v: (leaders.topFormat[0] || 'reels').charAt(0).toUpperCase() + (leaders.topFormat[0] || 'reels').slice(1), s: fmtFull(leaders.topFormat[1] || 0) + ' post pada dataset terbaru' },
    { k:'Pembaruan Terakhir', v: prettyLastUpdate(dashData().lastUpdate || '-'), s: 'Data followers harian dan engagement terbaru' }
  ];
  el.innerHTML = cards.map(function(card){
    return '<div class="summary-card ' + (card.cls || '') + '" title="' + escapeHtml(card.s) + '"><div class="k">' + card.k + '</div><div class="v">' + card.v + '</div><div class="s">' + card.s + '</div></div>';
  }).join('');
}

// ===== OVERVIEW CARDS =====
function renderCards(){
  const el = document.getElementById('cards');
  const accs = [...dashData().accounts].sort((a,b) => b.f - a.f);
  const cardClasses = ['cc','cg','ca','cr'];
  replaceWithFragment(el, accs.map((a, i) => {
    const cls = a.b ? 'acard brand' : 'acard ' + cardClasses[i % cardClasses.length];
    const tag = a.b ? '<span class="ctag bt">BRAND</span>' : '<span class="ctag ct">COMPETITOR</span>';
    const gCls = a.growthPct > 0 ? 'up' : a.growthPct < 0 ? 'down' : 'flat';
    const gIcon = a.growthPct > 0 ? '&#9650;' : a.growthPct < 0 ? '&#9660;' : '&#8213;';
    const deltaText = a.growthAbs > 0 ? 'naik' : a.growthAbs < 0 ? 'turun' : 'stabil';
    const erValue = a.er != null ? (a.er * 100).toFixed(2)+'%' : '-';
    const erBadgeClass = a.er >= 0.03 ? 'er-strong' : a.er >= 0.01 ? 'er-watch' : 'er-weak';
    const erBadgeLabel = a.er >= 0.03 ? 'Kuat' : a.er >= 0.01 ? 'Perlu dipantau' : 'Perlu perhatian';
    return `<article class="${cls}" aria-label="Ringkasan akun @${a.u}" title="Akun @${a.u}">
      <div class="ch"><span class="cun"><span class="account-label">${a.v ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="#405DE6" stroke="#405DE6" stroke-width="0" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M9 12l2 2 4-4" stroke="#FFF" stroke-width="2.5" fill="none"/></svg>' : ''}<span class="account-handle" title="@${a.u}">@${a.u}</span></span></span>${tag}</div>
      <div class="cfol"><div class="lb">Followers</div><div class="vl">${fmtFull(a.f)}</div><div class="gr ${gCls}" aria-label="Perubahan harian ${deltaText}">${gIcon} <span class="delta-label">${deltaText}</span> ${a.growthAbs >= 0 ? '+' : ''}${fmtFull(a.growthAbs)} (${pct(a.growthPct)})</div></div>
      <div class="csts">
        <div class="cst"><div class="sv">${fmtFull(a.fo)}</div><div class="sl">Following</div></div>
        <div class="cst"><div class="sv">${fmtFull(a.p)}</div><div class="sl">Posts</div></div>
      </div>
      <div class="csts4">
        <div class="cst"><div class="sv">${fmtFull(Math.round(a.al))}</div><div class="sl">Avg Likes</div></div>
        <div class="cst"><div class="sv">${a.ac != null ? a.ac.toFixed(1) : '-'}</div><div class="sl">Avg Comments</div></div>
        <div class="cst er-highlight ${erBadgeClass}" title="Engagement rate ${erBadgeLabel.toLowerCase()}"><div class="sv">${erValue}</div><div class="sl">ER</div><div class="er-context"><span class="er-context-icon" aria-hidden="true">${a.er >= 0.03 ? '&#9733;' : a.er >= 0.01 ? '&#9673;' : '&#33;'}</span><span>${erBadgeLabel}</span></div></div>
        <div class="cst"><div class="sv">${a.growthPct != null ? (a.growthPct > 0 ? '+' : '') + a.growthPct.toFixed(2)+'%' : '-'}</div><div class="sl">Growth</div></div>
      </div>
    </article>`;
  }).join(''));
}

// ===== FEATURE 1: GROWTH VELOCITY =====
function renderGrowthVelocity(){
  const el = document.getElementById('gvCards');
  const accs = dashData().accounts;
  const trend = dashData().trend || {};

  replaceWithFragment(el, accs.map((a, idx) => {
    const t = trend[a.u] || [];
    const len = t.length;

    const daily = len >= 2 ? t[len-1] - t[len-2] : 0;
    const dailyPct = len >= 2 && t[len-2] > 0 ? ((daily / t[len-2]) * 100) : 0;
    const weekIdx = Math.max(0, len - 7);
    const weekly = len >= 2 ? t[len-1] - t[weekIdx] : 0;
    const weeklyPct = t[weekIdx] > 0 ? ((weekly / t[weekIdx]) * 100) : 0;

    const sparkDays = Math.min(7, len - 1);
    let sparkData = [];
    for(let i = len - sparkDays; i < len; i++){
      sparkData.push(t[i] - (t[i-1] || t[i]));
    }
    const maxSpark = Math.max(...sparkData.map(Math.abs), 1);

    const dailyCls = daily > 0 ? 'up' : daily < 0 ? 'down' : 'flat';
    const weeklyCls = weekly > 0 ? 'up' : weekly < 0 ? 'down' : 'flat';
    const maxBar = Math.max(Math.abs(dailyPct), Math.abs(weeklyPct), 0.01);

    return `<div class="gv-card">
      <div class="gv-name"><span style="color:${COLORS[idx % COLORS.length]}">&#9679;</span> @${a.u}</div>
      <div class="gv-row">
        <span class="gv-label">Daily</span>
        <span class="gv-val ${dailyCls}">${daily >= 0 ? '+' : ''}${fmtFull(daily)} (${dailyPct >= 0 ? '+' : ''}${dailyPct.toFixed(3)}%)</span>
      </div>
      <div class="gv-bar"><div class="gv-bar-fill" style="width:${Math.min(Math.abs(dailyPct)/maxBar*100, 100)}%;background:${daily >= 0 ? 'var(--success)' : 'var(--danger)'}"></div></div>
      <div class="gv-row">
        <span class="gv-label">Weekly</span>
        <span class="gv-val ${weeklyCls}">${weekly >= 0 ? '+' : ''}${fmtFull(weekly)} (${weeklyPct >= 0 ? '+' : ''}${weeklyPct.toFixed(3)}%)</span>
      </div>
      <div class="gv-bar"><div class="gv-bar-fill" style="width:${Math.min(Math.abs(weeklyPct)/maxBar*100, 100)}%;background:${weekly >= 0 ? 'var(--success)' : 'var(--danger)'}"></div></div>
      <div class="gv-sparkline">${sparkData.map(v => {
        const h = Math.max(Math.abs(v)/maxSpark * 28, 2);
        const c = v >= 0 ? 'var(--success)' : 'var(--danger)';
        return `<div class="gv-spark-bar" style="height:${h}px;background:${c}"></div>`;
      }).join('')}</div>
    </div>`;
  }).join(''));
}

function renderPostSnapshot(){
  const container = document.getElementById('postSnapshotGrid');
  const summaryEl = document.getElementById('postCampaignSummary');
  const accountSelect = document.getElementById('psAccountFilter');
  const sortSelect = document.getElementById('psSort');
  const postFilterSelect = document.getElementById('psPostFilter');
  if(!container) return;

  const insights = (dashData() && dashData().post_insights) || {};
  const accounts = dashData().accounts || [];
  const usernames = accounts.map((acc) => typeof acc === 'string' ? acc : acc.u).filter(Boolean);
  if(!usernames.length){
    if(summaryEl) summaryEl.innerHTML = '';
    container.innerHTML = '<div class="ps-empty">Data akun belum tersedia.</div>';
    return;
  }

  if(accountSelect){
    const selectedBefore = accountSelect.value || 'all';
    accountSelect.innerHTML = '<option value="all">Semua akun</option>' + usernames.map((u) => `<option value="${u}">@${u}</option>`).join('');
    accountSelect.value = usernames.includes(selectedBefore) || selectedBefore === 'all' ? selectedBefore : 'all';
  }

  const selectedAccount = accountSelect ? (accountSelect.value || 'all') : 'all';
  const sortBy = sortSelect ? (sortSelect.value || 'viral_posts') : 'viral_posts';
  const selectedPostFilter = postFilterSelect ? (postFilterSelect.value || 'all') : 'all';

  let cards = usernames.map((username) => ({ username, insight: insights[username] || null }));
  if(selectedAccount !== 'all') cards = cards.filter((item) => item.username === selectedAccount);

  cards.sort((a, b) => {
    const ia = a.insight || {};
    const ib = b.insight || {};
    switch(sortBy){
      case 'average_post_er': return (Number(ib.average_post_er || 0) - Number(ia.average_post_er || 0));
      case 'average_likes': return (Number(ib.average_likes || 0) - Number(ia.average_likes || 0));
      case 'campaign_terms': return ((ib.campaign_terms || []).length - (ia.campaign_terms || []).length);
      case 'username': return a.username.localeCompare(b.username);
      case 'viral_posts':
      default: return (Number(ib.viral_posts || 0) - Number(ia.viral_posts || 0));
    }
  });

  if(summaryEl){
    const scoped = cards.map((item) => item.insight).filter(Boolean);
    const totalPosts = scoped.reduce((sum, item) => sum + ((item.posts || []).length || 0), 0);
    const totalViral = scoped.reduce((sum, item) => sum + Number(item.viral_posts || 0), 0);
    const totalUnder = scoped.reduce((sum, item) => sum + Number(item.underperform_posts || 0), 0);
    const campaignCounts = {};
    scoped.forEach((item) => {
      (item.campaign_terms || []).forEach((term) => {
        campaignCounts[term] = (campaignCounts[term] || 0) + 1;
      });
    });
    const topCampaign = Object.entries(campaignCounts).sort((x,y)=>y[1]-x[1])[0]?.[0] || '-';
    const topViral = cards.filter((item) => item.insight).sort((x,y)=>Number(y.insight.viral_posts||0)-Number(x.insight.viral_posts||0))[0];
    const topER = cards.filter((item)=>item.insight).sort((x,y)=>Number(y.insight.average_post_er||0)-Number(x.insight.average_post_er||0))[0];
    const items = [
      { k:'Total post teranalisis', v: fmtFull(totalPosts) },
      { k:'Viral / perlu optimasi', v: `${fmtFull(totalViral)} / ${fmtFull(totalUnder)}` },
      { k:'Tema campaign teratas', v: escapeHtml(topCampaign) },
      { k:'Akun paling viral', v: topViral ? `@${topViral.username}` : '-' },
      { k:'Akun dengan ER tertinggi', v: topER ? `@${topER.username}` : '-' },
    ];
    summaryEl.innerHTML = items.map((item)=>`<div class="ps-summary-card"><div class="ps-summary-k">${item.k}</div><div class="ps-summary-v">${item.v}</div></div>`).join('');
  }

  if(!cards.length){
    container.innerHTML = '<div class="ps-empty">Tidak ada akun sesuai filter.</div>';
    return;
  }

  const html = cards.map(({ username, insight }) => {
    if(!insight){
      return `<div class="ps-card"><div class="ps-card-title">@${username}</div><div class="ps-empty">Data postingan belum tersedia.</div></div>`;
    }
    const posts = insight.posts || [];
    const visiblePosts = selectedPostFilter === 'all' ? posts : posts.filter((post) => post.performance_label === selectedPostFilter);
    const bestPost = visiblePosts[0] || posts[0] || null;

    const averageLikes = Number.isFinite(insight.average_likes) ? fmtFull(insight.average_likes) : '-';
    const averageComments = Number.isFinite(insight.average_comments) ? fmtFull(insight.average_comments) : '-';
    const averagePostEr = Number.isFinite(insight.average_post_er) ? pct(Math.abs(insight.average_post_er)) : '-';
    const hashtagHtml = (insight.top_hashtags || []).slice(0, 3).map((tag) => `<span class="ps-chip">${escapeHtml(tag)}</span>`).join('') || '<span class="ps-chip muted">No hashtags</span>';
    const campaigns = (insight.campaign_terms || []).slice(0, 2).map((term) => escapeHtml(term)).join(', ');
    const campaignHtml = campaigns ? `<div class="ps-campaign">Tema campaign: ${campaigns}</div>` : '<div class="ps-campaign">Tema campaign: -</div>';

    let insightText = `Format ${titleCase(insight.dominant_type || 'unknown')} masih jadi kekuatan utama @${username}.`;
    if ((insight.viral_posts || 0) > (insight.underperform_posts || 0)) insightText = `${fmtFull(insight.viral_posts || 0)} postingan terakhir @${username} masuk kategori viral atau stabil kuat.`;
    else if ((insight.underperform_posts || 0) >= 3) insightText = `Beberapa postingan @${username} masih perlu optimasi agar performanya lebih konsisten.`;

    let previewHtml = '<div class="ps-post ps-empty">Tidak ada postingan sesuai filter.</div>';
    if (bestPost) {
      const label = bestPost.performance_label || 'normal';
      const labelText = label === 'viral' ? 'Viral' : label === 'underperform' ? 'Perlu Optimasi' : 'Stabil';
      const date = formatPostDate(bestPost.published_at);
      const caption = bestPost.caption_snippet || bestPost.caption || bestPost.shortcode || '';
      const postEr = Number.isFinite(bestPost.post_er) ? pct(Math.abs(bestPost.post_er)) : '-';
      const contentType = titleCase(bestPost.media_type || bestPost.type || insight.dominant_type || 'unknown');
      previewHtml = `<div class="ps-post ps-post-featured">
        <div class="ps-post-label">Postingan teratas</div>
        <div class="ps-post-head"><span class="ps-post-tag ${label}">${labelText}</span><span class="ps-post-meta">${date} · ${contentType}</span></div>
        <a class="ps-post-link" href="${bestPost.url || '#'}" target="_blank" rel="noreferrer">${escapeHtml(caption.slice(0, 42) || 'Lihat postingan')}</a>
        <div class="ps-post-caption">${escapeHtml(caption)}</div>
        <div class="ps-post-meta">${fmtFull(bestPost.likes)} likes · ${fmtFull(bestPost.comments)} komentar · ER ${postEr} · dibanding rata-rata akun ${averagePostEr}</div>
      </div>`;
    }

    return `<div class="ps-card">
      <div class="ps-card-header">
        <div>
          <div class="ps-card-title">@${username}</div>
          <div class="ps-card-meta">Ringkasan 12 postingan terakhir</div>
        </div>
        <div class="ps-card-format">${titleCase(insight.dominant_type || 'unknown')}</div>
      </div>
      <div class="ps-card-main">
        <div class="ps-card-kpis">
          <div class="ps-kpi"><div class="ps-kpi-v">${averageLikes}</div><div class="ps-kpi-k">Avg likes</div></div>
          <div class="ps-kpi"><div class="ps-kpi-v">${averageComments}</div><div class="ps-kpi-k">Avg komentar</div></div>
          <div class="ps-kpi"><div class="ps-kpi-v">${averagePostEr}</div><div class="ps-kpi-k">Rata-rata ER</div></div>
        </div>
        <div class="ps-card-stats">
          <span class="ps-chip">Post viral ${fmtFull(insight.viral_posts || 0)}</span>
          <span class="ps-chip">Perlu optimasi ${fmtFull(insight.underperform_posts || 0)}</span>
        </div>
        ${campaignHtml}
        <div class="ps-card-hashtags">${hashtagHtml}</div>
        <div class="ps-card-insight">${insightText}</div>
      </div>
      <div class="ps-card-posts">${previewHtml}</div>
    </div>`;
  }).join('');

  container.innerHTML = html;
}
window.renderPostSnapshot = renderPostSnapshot;

// ===== RANKING TABLE =====
function renderTable(){
  const brand = getBrand();
  const sorted = [...dashData().accounts].sort((a,b) => {
    let va, vb;
    switch(dashState().sortCol){
      case 'rank': va = b.f; vb = a.f; break;
      case 'username': va = a.u.toLowerCase(); vb = b.u.toLowerCase(); return dashState().sortAsc ? (va < vb ? -1 : 1) : (va > vb ? -1 : 1);
      case 'followers': va = a.f; vb = b.f; break;
      case 'following': va = a.fo; vb = b.fo; break;
      case 'posts': va = a.p; vb = b.p; break;
      case 'avgLikes': va = a.al; vb = b.al; break;
      case 'avgComments': va = a.ac; vb = b.ac; break;
      case 'er': va = a.er; vb = b.er; break;
      case 'verified': va = a.v ? 1 : 0; vb = b.v ? 1 : 0; break;
      case 'gap': va = Math.abs(a.f - brand.f); vb = Math.abs(b.f - brand.f); break;
      default: va = a.f; vb = b.f;
    }
    return dashState().sortAsc ? va - vb : vb - va;
  });

  document.querySelectorAll('.rtbl thead th').forEach(th => {
    th.classList.toggle('sd', th.getAttribute('data-s') === dashState().sortCol);
  });

  const tbody = document.getElementById('rtb');
  const ranked = [...dashData().accounts].sort((a,b) => b.f - a.f);
  replaceWithFragment(tbody, sorted.map(a => {
    const rank = ranked.findIndex(x => x.u === a.u) + 1;
    const rCls = rank === 1 ? 'r1' : rank === 2 ? 'r2' : rank === 3 ? 'r3' : '';
    const gap = a.f - brand.f;
    const gapCls = a.b ? 'gz' : gap > 0 ? 'gp' : gap < 0 ? 'gn' : 'gz';
    const erCls = a.er >= 0.2 ? 'er-high' : a.er >= 0.1 ? 'er-mid' : 'er-low';
    return `<tr class="${a.b ? 'brow' : ''}">
      <td><span class="rn ${rCls}">#${rank}</span></td>
      <td title="@${a.u}"><span class="tu">${a.v ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="#405DE6" stroke="#405DE6" stroke-width="0" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M9 12l2 2 4-4" stroke="#FFF" stroke-width="2.5" fill="none"/></svg>' : ''}<span class="account-handle">@${a.u}</span></span></td>
      <td>${fmtFull(a.f)}</td>
      <td>${fmtFull(a.fo)}</td>
      <td>${fmtFull(a.p)}</td>
      <td>${fmtFull(Math.round(a.al))}</td>
      <td>${a.ac != null ? a.ac.toFixed(1) : '-'}</td>
      <td><span class="er-badge ${erCls}">${a.er != null ? (a.er * 100).toFixed(2)+'%' : '-'}</span></td>
      <td>${a.v ? '&#10003;' : '-'}</td>
      <td><span class="${gapCls}">${a.b ? '-' : (gap >= 0 ? '+' : '') + fmtFull(gap)}</span></td>
    </tr>`;
  }).join(''));
}

document.querySelectorAll('.rtbl thead th').forEach(th => {
  th.addEventListener('click', () => {
    const col = th.getAttribute('data-s');
    if(dashState().sortCol === col) setDashboardSort(col, !dashState().sortAsc);
    else setDashboardSort(col, false);
    renderTable();
  });
});

function renderAlerts(){
  const sec = document.getElementById('alertSection');
  const list = document.getElementById('alertList');
  if(!dashData().alerts || dashData().alerts.length === 0){
    sec.style.display = 'none';
    return;
  }
  sec.style.display = 'block';
  list.innerHTML = '<div class="al-list">' + dashData().alerts.map(a => {
    const isDanger = a.jenis && a.jenis.toLowerCase().includes('drop');
    const pctCls = a.persen >= 0 ? 'up' : 'dn';
    return `<div class="al-item${isDanger ? ' danger' : ''}">
      <span class="al-date">${a.tanggal || '-'}</span>
      <span class="al-akun">@${a.akun}</span>
      <span class="al-info">${a.jenis || ''} ${a.catatan ? '- ' + a.catatan : ''}</span>
      <span class="al-pct ${pctCls}">${a.persen != null ? (a.persen >= 0 ? '+' : '') + a.persen.toFixed(2) + '%' : ''}</span>
    </div>`;
  }).join('') + '</div>';
}

window.renderExecutiveSummary = renderExecutiveSummary;
window.renderTodaySummary = renderTodaySummary;
